<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
namespace Packlink\PrestaShop\Classes\BusinessLogicServices;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Logeecom\Infrastructure\TaskExecution\Interfaces\AsyncProcessUrlProviderInterface;

/**
 * Class AsyncProcessUrlProvider.
 *
 * Provides the public URL of the module's async-process front controller. Under core V2 the
 * task-runner stack resolves the async-process endpoint through this contract instead of the
 * Configuration service, so PrestaShop (which runs in Standalone / TaskRunner mode) supplies it here.
 *
 * @package Packlink\PrestaShop\Classes\BusinessLogicServices
 */
class AsyncProcessUrlProvider implements AsyncProcessUrlProviderInterface
{
    /**
     * @inheritDoc
     */
    public function getAsyncProcessUrl($guid)
    {
        return ConfigurationService::getInstance()->getAsyncProcessUrl($guid);
    }
}
