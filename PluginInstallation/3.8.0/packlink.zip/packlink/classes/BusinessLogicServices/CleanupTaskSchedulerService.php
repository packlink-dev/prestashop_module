<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
namespace Packlink\PrestaShop\Classes\BusinessLogicServices;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Logeecom\Infrastructure\ServiceRegister;
use Logeecom\Infrastructure\TaskExecution\LegacyTaskAdapter;
use Logeecom\Infrastructure\TaskExecution\QueueItem;
use Logeecom\Infrastructure\TaskExecution\Scheduler\ScheduleCheckTask;
use Logeecom\Infrastructure\TaskExecution\Tasks\TaskCleanupTask;
use Packlink\BusinessLogic\Scheduler\DTO\ScheduleConfig;
use Packlink\BusinessLogic\Scheduler\Interfaces\SchedulerInterface;

/**
 * Class CleanupTaskSchedulerService
 *
 * @package Packlink\PrestaShop\Classes\BusinessLogicServices
 */
class CleanupTaskSchedulerService
{
    /**
     * Schedules a new task in charge of deleting old schedule check tasks.
     *
     * Uses the core V2 scheduler contract. TaskCleanupTask is a legacy infrastructure task, so it is
     * wrapped in a LegacyTaskAdapter to be scheduled through the new SchedulerInterface.
     *
     * @return void
     */
    public static function scheduleTaskCleanupTask()
    {
        /** @var SchedulerInterface $scheduler */
        $scheduler = ServiceRegister::getService(SchedulerInterface::CLASS_NAME);

        $cleanupTask = new TaskCleanupTask(
            ScheduleCheckTask::getClassName(),
            array(QueueItem::COMPLETED),
            3600
        );

        $scheduler->scheduleHourly(
            new LegacyTaskAdapter($cleanupTask),
            new ScheduleConfig(0, 0, 10)
        );
    }
}
