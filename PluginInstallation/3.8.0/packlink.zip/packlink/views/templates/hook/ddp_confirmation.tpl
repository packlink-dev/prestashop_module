{**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 *}
{*
* Packlink duty line for the order confirmation page.
*
* Shown only for orders that bought a duties-paid (DDP) shipping option. It states the
* duty amount the shopper already paid as part of the shipping price — it is purely
* informative and never adds to any total. Both values are assigned pre-formatted by
* getDdpConfirmationBlock() in packlink.php.
*}
<div class="pl-ddp-confirmation">
    <span class="pl-ddp-label">{$plDdpLabel|escape:'html':'UTF-8'}:</span>
    <span class="pl-ddp-amount">{$plDdpAmount|escape:'html':'UTF-8'}</span>
</div>
