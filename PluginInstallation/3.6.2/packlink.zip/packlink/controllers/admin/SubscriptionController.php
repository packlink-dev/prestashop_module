<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use Packlink\PrestaShop\Classes\Utility\PacklinkPrestaShopUtility;
use Packlink\BusinessLogic\Controllers\SubscriptionController as BaseSubscriptionController;

/** @noinspection PhpIncludeInspection */
require_once rtrim(_PS_MODULE_DIR_, '/') . '/packlink/vendor/autoload.php';

/**
 * Class SubscriptionController
 */
class SubscriptionController extends PacklinkBaseController
{
    /**
     * Returns the merchant's subscription plan tier and display name.
     */
    public function displayAjaxGetPlan()
    {
        $controller = new BaseSubscriptionController();

        PacklinkPrestaShopUtility::dieJson($controller->getPlan()->toArray());
    }

    /**
     * Returns promotional banner data for the shipping services page.
     */
    public function displayAjaxGetPromotionalBanner()
    {
        $controller = new BaseSubscriptionController();

        PacklinkPrestaShopUtility::dieJson($controller->getPromotionalBanner()->toArray());
    }
}
