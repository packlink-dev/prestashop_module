<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
use Packlink\BusinessLogic\Configuration;
use Logeecom\Infrastructure\ServiceRegister;
use Packlink\PrestaShop\Classes\Bootstrap;
use Packlink\PrestaShop\Classes\Utility\PacklinkPrestaShopUtility;

/**
 * Class PacklinkIntegrationStatusModuleFrontController
 *
 * Returns the current integration activation status.
 * Called from StateController.js after the initial state check.
 */
class PacklinkIntegrationstatusModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();

        Bootstrap::init();
    }

    public function initContent()
    {
        /** @var \Packlink\PrestaShop\Classes\BusinessLogicServices\ConfigurationService $configService */
        $configService = ServiceRegister::getService(Configuration::CLASS_NAME);

        PacklinkPrestaShopUtility::dieJson(array(
            'status' => $configService->getIntegrationStatus() ?: 'ACTIVE',
        ));
    }
}
