<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
use Packlink\PrestaShop\Classes\Utility\PacklinkPrestaShopUtility;
use Packlink\BusinessLogic\Controllers\RegistrationRegionsController as BaseRegistrationRegionsController;

/** @noinspection PhpIncludeInspection */
require_once rtrim(_PS_MODULE_DIR_, '/') . '/packlink/vendor/autoload.php';

/**
 * Class RegistrationRegionsController
 */
class RegistrationRegionsController extends PacklinkBaseController
{
    /**
     * Returns regions available for Packlink account registration.
     */
    public function displayAjaxGetRegions()
    {
        $controller = new BaseRegistrationRegionsController();

        PacklinkPrestaShopUtility::dieDtoEntities($controller->getRegions());
    }
}
