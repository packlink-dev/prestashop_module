<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
namespace Packlink\PrestaShop\Classes\BusinessLogicServices;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Logeecom\Infrastructure\Logger\Logger;
use Packlink\BusinessLogic\Configuration;

class ConfigurationService extends Configuration
{
    /**
     * Threshold between two runs of scheduler.
     */
    const SCHEDULER_TIME_THRESHOLD = 150;
    /**
     * @inheritdoc
     */
    const MIN_LOG_LEVEL = Logger::ERROR;
    /**
     * Default HTTP method to use for async call.
     */
    const ASYNC_CALL_METHOD = 'GET';
    /**
     * Singleton instance of this class.
     *
     * @var static
     */
    protected static $instance;
    /**
     * @var string
     */
    private $moduleVersion;

    /**
     * Config key older module versions used for customs mapping rows core's CustomsMapping did not
     * declare. Core now declares them all; this remains only so PacklinkInstaller can migrate a
     * merchant's existing selection into the core mapping.
     */
    const CUSTOMS_MAPPING_EXTRAS = 'customsMappingExtras';

    /**
     * Returns current system identifier.
     *
     * @return string Current system identifier.
     */
    public function getCurrentSystemId()
    {
        return \Configuration::get('PS_SHOP_DEFAULT');
    }

    /**
     * Returns the customs mapping selections stored by older module versions. Migration source only.
     *
     * @return array Map of mapping field name => selected source key.
     */
    public function getCustomsMappingExtras()
    {
        $raw = $this->getConfigValue(self::CUSTOMS_MAPPING_EXTRAS);
        if (empty($raw)) {
            return array();
        }

        $decoded = json_decode($raw, true);

        return is_array($decoded) ? $decoded : array();
    }


    /**
     * Returns web-hook callback URL for current system.
     *
     * @return string Web-hook callback URL.
     */
    public function getWebHookUrl()
    {
        return $this->getFrontendUrl('webhooks');
    }

    /**
     * Returns status update web-hook callback URL for current system.
     *
     * @return string Status Update Web-hook callback URL.
     */
    public function getStatusUpdateUrl()
    {
        return $this->getFrontendUrl('registrationwebhooks');
    }

    /**
     * Returns async process starter URL.
     *
     * @param string $guid Process identifier.
     *
     * @return string Formatted URL of async process starter endpoint.
     */
    public function getAsyncProcessUrl($guid)
    {
        $params = array('guid' => $guid);
        if ($this->isAutoTestMode()) {
            $params['auto-test'] = 1;
        }

        return $this->getFrontendUrl('asyncprocess', $params);
    }

    /**
     * Returns backup carrier ID.
     *
     * @return int|null Backup carrier ID if found; otherwise, NULL.
     */
    public function getBackupCarrierId()
    {
        return $this->getConfigValue('backupCarrierId') ?: null;
    }

    /**
     * Sets backup carrier ID.
     *
     * @param int $carrierId ID of the backup carrier.
     */
    public function setBackupCarrierId($carrierId)
    {
        $this->saveConfigValue('backupCarrierId', $carrierId);
    }

    /**
     * Sets Integration identifier.
     *
     * @param string $integrationId ID of the integration.
     *
     * @return \Logeecom\Infrastructure\Configuration\ConfigEntity
     */
    public function setIntegrationId($integrationId)
    {
        return parent::setIntegrationId($integrationId);
    }

    /**
     * Retrieves Integration identifier.
     *
     * @return string | null  IntegrationId configuration.
     */
    public function getIntegrationId()
    {
        return parent::getIntegrationId();
    }

    /**
     * Sets backup carrier ID.
     *
     * @param string $webhookSecret
     *
     * @return \Logeecom\Infrastructure\Configuration\ConfigEntity
     */
    public function setWebhookSecret($webhookSecret)
    {
        return parent::setWebhookSecret($webhookSecret);
    }

    /**
     * Retrieves Webhook secret.
     *
     * @return string | null  Webhook Secret configuration.
     */
    public function getWebhookSecret()
    {
        return parent::getWebhookSecret();
    }

    /**
     * Sets Integration Guid.
     *
     * @param string $webhookSecret
     *
     * @return \Logeecom\Infrastructure\Configuration\ConfigEntity
     */
    public function setIntegrationGuid($integrationGuid)
    {
        return parent::setIntegrationGuid($integrationGuid);
    }

    /**
     * Retrieves Integration Guid.
     *
     * @return string | null  Integration Guid configuration.
     */
    public function getIntegrationGuid()
    {
        return parent::getIntegrationGuid();
    }

    /**
     * Retrieves integration name.
     *
     * @return string Integration name.
     */
    public function getIntegrationName()
    {
        return 'PrestaShop';
    }

    /**
     * Returns order draft source.
     *
     * @return string
     */
    public function getDraftSource()
    {
        return 'module_prestashop';
    }

    /**
     * Gets the current version of the module/integration.
     *
     * @return string The version number.
     */
    public function getModuleVersion()
    {
        if (!$this->moduleVersion) {
            $this->moduleVersion = \Module::getInstanceByName('packlink')->version;
        }

        return $this->moduleVersion;
    }

    /**
     * Gets the name of the integrated e-commerce system.
     * This name is related to Packlink API which can be different from the official system name.
     *
     * @return string The e-commerce name.
     */
    public function getECommerceName()
    {
        return 'prestashop_2';
    }

    /**
     * Gets the current version of the integrated e-commerce system.
     *
     * @return string The version number.
     */
    public function getECommerceVersion()
    {
        return _PS_VERSION_;
    }

    /**
     * Retrieves integration status.
     *
     * @return string|null
     */
    public function getIntegrationStatus()
    {
        return parent::getIntegrationStatus();
    }

    /**
     * Sets integration status.
     *
     * @param string $status
     *
     * @return \Logeecom\Infrastructure\Configuration\ConfigEntity
     */
    public function setIntegrationStatus($status)
    {
        return parent::setIntegrationStatus($status);
    }

    /**
     * Returns whether the integration is currently active.
     * Integration is considered active unless explicitly set to DISABLED.
     *
     * @return bool
     */
    public function isIntegrationActive()
    {
        return parent::isIntegrationActive();
    }

    /**
     * Gets the URL of the frontend controller.
     *
     * @param string $controller Controller name.
     * @param array $params Route parameters.
     *
     * @return string
     */
    private function getFrontendUrl($controller, $params = array())
    {
        $shopId = \Configuration::get('PS_SHOP_DEFAULT');

        return \Context::getContext()->link->getModuleLink('packlink', $controller, $params, null, null, $shopId);
    }
}
