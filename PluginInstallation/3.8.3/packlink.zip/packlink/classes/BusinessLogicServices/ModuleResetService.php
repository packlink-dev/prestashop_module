<?php
/**
 * 2026 Packlink
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author    Packlink <support@packlink.com>
 * @copyright 2026 Packlink Shipping S.L
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */
namespace Packlink\PrestaShop\Classes\BusinessLogicServices;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Logeecom\Infrastructure\Logger\Logger;
use Packlink\BusinessLogic\IntegrationRegistration\Interfaces\IntegrationRegistrationDataProviderInterface;
use Packlink\BusinessLogic\IntegrationRegistration\Interfaces\ModuleResetServiceInterface;

class ModuleResetService implements ModuleResetServiceInterface
{
    /** @var IntegrationRegistrationDataProviderInterface $dataProvider */
    private $dataProvider;

    public function __construct($dataProvider)
    {
        $this->dataProvider = $dataProvider;
    }

    /**
     * Erases integration data keeping the module installed
     * in the target shop system, available for a new Packlink connection.
     *
     * Nulls out integrationId, integrationGuid, and webhookSecret
     * from the database via ConfigurationService.
     *
     * @return bool
     */
    public function resetModule()
    {
        try {
            $this->dataProvider->deleteIntegrationData();
            $this->dataProvider->deleteToken();

            return true;
        } catch (\Exception $e) {
            Logger::logError(
                'Failed to reset module integration data: ' . $e->getMessage(),
                'Prestashop_module',
                array('trace' => $e->getTraceAsString())
            );

            return false;
        }
    }
}
